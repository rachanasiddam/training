package test;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Cipher {
	
	public static void main(String[] args) {

	    File file = new File("cipher.txt");
	    try {
	        Scanner sc = new Scanner(file);
	        String str = sc.nextLine();
	        System.out.println(str);

	        String[] lineVector = str.split(",");
	        int length = lineVector.length;
	        //System.out.println(length);
	        
	        int[] data1 = new int[23];
	        int i;
	        
	        for(i=0; i < 23; i++){
	        	data1[i] = Integer.parseInt(lineVector[i]);
	        }
	        int[] data2 = new int[20];
	        for(i=0; i < 20; i++){
	        	data2[i] = data1[i]^data1[i+3];
	        	//System.out.print(data2[i]+",");
	        }
	        int[] data3 = new int[20];
	        for(i=0; i < 20; i++){
	        	data3[i] = data2[i]^32;
	        	//System.out.print(data3[i]+",");
	        }
	        System.out.print(20^112);
	
	        sc.close();
	    }catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}