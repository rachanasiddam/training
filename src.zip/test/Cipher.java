package test;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Cipher {
	public static void main(String[] args) {

	    File file = new File("cipher.txt");
	    try {
	        Scanner sc = new Scanner(file);
	        String str = sc.nextLine();
	        System.out.println(str);

	        String[] lineVector = str.split(",");
	        
	        int[] data = new int[30];
	        int i;
	        
	        for(i=0;i<30;i++){
	        	data[i] = Integer.parseInt(lineVector[i]);
	        }
	        int[] data1 = shiftLeft(data);
	        for(i=0;i<30;i++){
	        	System.out.print(data1[i]);
	        }
	        

	        sc.close();
	    }catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	public static int[] shiftLeft(int[] nums) {
	    if (nums == null || nums.length <= 1) {
	        return nums;
	    }
	    int num1 = nums[0];
	    int num2 = nums[1];
	    int num3 = nums[2];
	    System.arraycopy(nums, 3, nums, 0, nums.length - 3);
	    nums[nums.length - 3] = num1;
	    nums[nums.length - 2] = num2;
	    nums[nums.length - 1] = num3;
	    return nums;
	}
}
